﻿$(function(){
    let num = 0;
    let line;

    const items = $('#morebox ul li');
    const total = items.length;

    items.hide();
    function setLine(){
        const w = $(window).width();

        if (w < 641) line = 3;
        else if (w <1200) line = 4;
        else line = 5;
    }

    function init(){
        setLine();
        num = line;

        items.hide();
        items.slice(0, num).show();
    }

    $('.more_btn button').on('click', function(e){
        e.preventDefault();
        num = Math.min(num + line, total);
        items.slice(0, num).fadeIn();

        if (num >= total){
            $('.more_btn').fadeOut();
        }
    });
    $(window).on('resize', function(){
        init();
        $('.more_btn').show();
    });
    init();
});