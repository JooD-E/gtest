﻿$(function(){
    let count = 0;
    let step;

    const items = $('#morebox ul li');
    const total = items.length;

    items.hide();
    function setStep(){
        const w = $(window).width();

        if (w < 641) step = 3;
        else if (w < 1200) step = 4;
        else step = 5;
    }

    function init(){
        setStep();

        count = step;

        items.hide()
        items.slice(0, count).show();
    }
    $('.more_btn button').on('click', function (e){
        e.preventDefault();
        count = Math.min(count + step, total);
        items.slice(0, count).fadeIn();

        if (count >= total){
            $('.more_btn').fadeOut();
        }
    });
    $(window).on('resize', function(){
        init();
        $('.more_btn').show();
    });
    init();
});