$(function(){
    $('.slider').slick({
        dots:true,
        autoplay:true,
        autoplaySpeed:2000,
        infinity:true,
        slidesToShow:4,
        slidesToScroll:1,
        responsive:[
            {
                breakpoint: 1300,
                settings: {
                    slidesToShow:3,
                    slidesToScroll:1
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow:2,
                    slidesToScroll:1
                }
            },
            {
                breakpoint: 510,
                settings: {
                    slidesToShow:1,
                    slidesToScroll:1
                }
            }
        ]
    });
    $('.slick-buttons a').on('click', function(e){
        const n = $(this).index()

        if (n == 0){
            $('.slider').slick('slickUnfilter');
        }else if (n == 1){
            $('.slider').slick('slickUnfilter')
            $('.slider').slick('slickFilter', $('.slider li').filter('.city'));
        }else if (n == 2) {
            $('.slider').slick('slickUnfilter')
            $('.slider').slick('slickFilter', $('.slider li').filter('.mount'))
        }else {
            $('.slider').slick('slickUnfilter')
            $('.slider').slick('slickFilter', $('.slider li').filter('.sea'))
        }

        e.preventDefault();
    })

});