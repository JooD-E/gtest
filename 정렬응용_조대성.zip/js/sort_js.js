document.addEventListener("DOMContentLoaded", function(){
    const select = document.querySelector("select");
    const ul = document.querySelector("#content ul");

    select.addEventListener("change", function(){
        const ab = this.value;
        const lis = Array.from(document.querySelectorAll("#content ul li"));
        const strNum = ab;

        slideTarget(strNum.substr(4,1));

        function slideTarget(n){

            let pricelis;

            if (n == 0){
                location.reload(true);
            } else if( n == 1){
                pricelis = lis.sort(function (a,b){
                    const dateA = new Date(a.querySelector("span.date").textContent);
                    const dateB = new Date(b.querySelector("span.date").textContent);
                    return dateB - dateA
                });
            } else if (n == 2){
                pricelis = lis.sort(function (a,b){
                    const priceA = parseInt(a.querySelector("span.price").textContent.replace(/[^0-9]/g,""));
                    const priceB = parseInt(b.querySelector("span.price").textContent.replace(/[^0-9]/g,""));
                    return priceB - priceA
                });
            }else {
                pricelis = lis.sort(function (a,b){
                    const priceA = parseInt(a.querySelector("span.price").textContent.replace(/[^0-9]/g,""));
                    const priceB = parseInt(b.querySelector("span.price").textContent.replace(/[^0-9]/g,""));
                    return priceA - priceB
                });
            }
            if (pricelis){
                ul.innerHTML = "";
                pricelis.forEach(li => ul.appendChild(li));
            }
        }
    });

});